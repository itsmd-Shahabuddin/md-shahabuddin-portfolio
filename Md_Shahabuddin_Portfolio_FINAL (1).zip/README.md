# Md Shahabuddin — Portfolio Website

## What to edit
Open `settings.json` and put your real links:
- github
- linkedin

## Deploy on GitHub Pages
Repo Settings → Pages → Deploy from a branch → main / (root) → Save